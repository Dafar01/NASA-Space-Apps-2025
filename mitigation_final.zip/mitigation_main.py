# main.py
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pathlib import Path
import os

BASE_DIR = Path(__file__).parent.resolve()

app = FastAPI()

# Serve /static and /node_modules from absolute paths (robust to cwd)
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
app.mount("/node_modules", StaticFiles(directory=BASE_DIR / "node_modules"), name="node_modules")

templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/favicon.ico")
async def favicon():
    path = BASE_DIR / "static" / "favicon.ico"
    return FileResponse(path) if path.exists() else HTMLResponse(status_code=204)
