// static/main.js

// === Imports (work with the import map you added in index.html) ===
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

// Layers
const LAYERS = { DEFAULT: 0, DART: 1 };

// === DOM refs ===
const container  = document.getElementById('viewer');
const loadingEl  = document.getElementById('loading');
const progressEl = document.getElementById('progress');
const btnStart   = document.getElementById('btnStart'); // enabled when assets finish

// ---- Simulation config ----
const SIM = {
  UNIT_KM_PER_SCENE_UNIT: 1000,
  DEFLECTION_SCALE: 1.0e-8,

  APPROACH_SPEEDUP: 100,      // ← increase this to go even faster (e.g., 20 or 30)
  APPROACH_MIN_TIME: 0.35,   

  IMPACT_FLASH_TIME: 2.4,   // how long the bright flash swells/fades
  IMPACT_PHASE_TIME: 3.8,   // how long we STAY in 'impact' before 'deflect'

  DEFLECTION_TIME: 6.0,
  PARTICLE_COUNT: 120,
  PARTICLE_LIFETIME: 0.8,

  ASTEROID_INWARD_SPEED: 0.25,

  FRAGMENT_COUNT: 70,
  FRAGMENT_SIZE_MIN: 0.08,
  FRAGMENT_SIZE_MAX: 0.22,
};

// ---- Runtime state ----
const STATE = {
  phase: 'idle',
  t0: 0,
  t: 0,
  approach: null,
  deflect: null,
  line: null,
  impactGroup: null,
};


// === Mitigation options (from your menu doc) ===
const OPTIONS = [
  {
    id: "baseline",
    label: "Baseline — No Mitigation",
    tooltip: "Default outcome if nothing is done — shows crater, blast, and people affected.",
    delta_v_m_s: 0,
    deflection_km_assume_10yr: 0,
    success_probability: 0.0,
    crater_multiplier: 1.0,
    people_multiplier: 1.0,
    vfx: "BASELINE"
  },
  {
    id: "dart_grazing",
    label: "Nuclear Detonation",
    tooltip: "Partial hit, small momentum transfer. Slight course change; minor reduction in damage.",
    delta_v_m_s: 0.0005,
    deflection_km_assume_10yr: 157.68,
    success_probability: 0.30,
    crater_multiplier: 0.95,
    people_multiplier: 0.80,
    vfx: "small_impact_flash"
  },
  {
    id: "dart_nominal",
    label: "DART — Kinetic Impact",
    tooltip: "Clean hit similar to DART. Moderate momentum transfer; significant reduction in impact severity.",
    delta_v_m_s: 0.003,
    deflection_km_assume_10yr: 946.08,
    success_probability: 0.70,
    crater_multiplier: 0.40,
    people_multiplier: 0.20,
    vfx: "projectile_hit_then_shift"
  },
  {
    id: "Gravity Tractor",
    label: "DART — High Momentum Transfer (β-enhanced)",
    tooltip: "Best-case DART scenario (high ejecta momentum). Large trajectory shift that likely avoids Earth.",
    delta_v_m_s: 0.01,
    deflection_km_assume_10yr: 3153.60,
    success_probability: 0.92,
    crater_multiplier: 0.0,
    people_multiplier: 0.0,
    vfx: "big_impact_and_orbit_shift"
  },
  {
    id: "Evacuation",
    label: "DART — Fragmentation Side-effect",
    tooltip: "Impact shatters the target into fragments. Some fragments may still hit — risk is redistributed.",
    delta_v_m_s: 0.001,
    deflection_km_assume_10yr: 315.36,
    success_probability: 0.45,
    crater_multiplier: 0.6,
    people_multiplier: 0.6,
    vfx: "fragment_burst"
  }
];



// === Scene / Camera / Renderer ===
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0b0b12);

const camera = new THREE.PerspectiveCamera(
  60, container.clientWidth / container.clientHeight, 0.1, 5000
);
camera.position.set(6, 3, 8);
// Camera renders both layers
camera.layers.enable(LAYERS.DEFAULT);
camera.layers.enable(LAYERS.DART);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(container.clientWidth, container.clientHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.shadowMap.enabled = true;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.2;
container.appendChild(renderer.domElement);

// Image-based lighting (IBL)
const pmrem = new THREE.PMREMGenerator(renderer);
scene.environment = pmrem.fromScene(new RoomEnvironment(renderer), 0.04).texture;

// === Global Lights (now ONLY on DART layer) ===
const hemiLight = new THREE.HemisphereLight(0xffffff, 0x222233, 1.0);
hemiLight.position.set(0, 1, 0);
hemiLight.layers.set(LAYERS.DART);
scene.add(hemiLight);

const dirLight = new THREE.DirectionalLight(0xffffff, 1.8);
dirLight.position.set(10, 15, 7);
dirLight.castShadow = true;
dirLight.shadow.mapSize.set(1024, 1024);
dirLight.layers.set(LAYERS.DART);
scene.add(dirLight);

const amb = new THREE.AmbientLight(0xffffff, 0.25);
amb.layers.set(LAYERS.DART);
scene.add(amb);

// === Stars (space backdrop) ===
addStarfield(2500, 800);

// === Controls ===
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.05;
controls.target.set(0, 0.5, 0);
controls.update();

// === Render loop ===
const clock = new THREE.Clock();
function animate() {
  const dt = clock.getDelta();
  controls.update();

  // --- NEW: asteroid inward drift (only while active) ---
  if (STATE.inward?.active && window.__bennu) {
    window.__bennu.position.addScaledVector(STATE.inward.v, dt);
  }


  // --- Simulation phases ---
  if (STATE.phase !== 'idle') {
    const tNow = nowSec();
    STATE.t = tNow - STATE.t0;

    if (STATE.phase === 'launch') {
      const { start, end, duration } = STATE.launch;
      let k = Math.min(STATE.t / duration, 1);
      // ease-out so it feels like bursting out of Earth
      k = 1 - Math.pow(1 - k, 3);
    
      const dart  = window.__dart;
      const bennu = window.__bennu;
    
      lerpVec3(dart.position, start, end, k);
    
      const bennuPos = new THREE.Vector3();
      bennu.getWorldPosition(bennuPos);
      dart.lookAt(bennuPos);
    
      if (k >= 1) {
        STATE.phase = 'approach';
        STATE.t0 = tNow;
        // ensure approach starts exactly from exit point
        dart.position.copy(end);
      }
    }
    

    if (STATE.phase === 'approach') {
      const { start, end, duration } = STATE.approach;
      const dart  = window.__dart;
      const bennu = window.__bennu;
    
      const k = Math.min(STATE.t / duration, 1);
      lerpVec3(dart.position, start, end, k);
      dart.lookAt(end);
    
      // Animate the dashed approach line (unchanged)
      if (STATE.line?.material?.dashOffset !== undefined) {
        STATE.line.material.dashOffset = -k * 5.0;
      }
    
      // --- Collision detection against Bennu's current world position ---
      const bennuPos = new THREE.Vector3();
      bennu.getWorldPosition(bennuPos);
    
      const impactThreshold = STATE.contactDistance ?? 0.25;
      const dist = dart.position.distanceTo(bennuPos);
    
      // Impact if we touched (dist <= threshold) OR we reached the end anyway
      if (dist <= impactThreshold || k >= 1) {
        // Hide the dart immediately on impact
        dart.visible = false;
    
        // Remove the approach line
        if (STATE.line) { scene.remove(STATE.line); STATE.line = null; }
    
        // Trigger explosion *right now* at the contact point (use dart's position)
        const impactFX = spawnImpactFX(dart.position.clone());
        scene.add(impactFX);
        STATE.impactGroup = impactFX;
    
        // Advance phase immediately
        STATE.phase = 'impact';
        // Stop the inward drift the moment we impact
        if (STATE.inward) STATE.inward.active = false;

        STATE.t0 = nowSec();
      }
    }
    
    
   else if (STATE.phase === 'impact') {
    if (STATE.impactGroup) updateImpactFX(STATE.impactGroup);
  
    // Stay in IMPACT longer before moving to DEFLECT
    if (STATE.t >= SIM.IMPACT_PHASE_TIME) {
      STATE.phase = 'deflect';
      STATE.t0 = tNow;
    }
  }
  
    else if (STATE.phase === 'deflect') {
      const { v, duration } = STATE.deflect;
      const step = v.clone().multiplyScalar(dt);
      if (window.__bennu) window.__bennu.position.add(step);
      if (STATE.t / duration >= 1) {
        STATE.phase = 'done';
        if (btnStart) btnStart.disabled = false;
      }
    }
  }

  renderer.render(scene, camera);
  requestAnimationFrame(animate);
}
animate();

// === Resize handling ===
window.addEventListener('resize', onWindowResize, false);
function onWindowResize() {
  const w = container.clientWidth;
  const h = container.clientHeight;
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  renderer.setSize(w, h);
}

// === Error overlay ===
function showFatalError(msg) {
  const el = document.createElement('div');
  el.style.position = 'fixed';
  el.style.top = '0';
  el.style.left = '0';
  el.style.right = '0';
  el.style.background = 'rgba(160,0,0,0.9)';
  el.style.color = '#fff';
  el.style.padding = '8px 12px';
  el.style.font = '14px/1.4 system-ui, sans-serif';
  el.style.zIndex = '999999';
  el.textContent = msg;
  document.body.appendChild(el);
}

// === Progress HUD helpers ===
function setProgress(pct) {
  if (progressEl) progressEl.textContent = `${pct}%`;
}

// === Simulation start ===
function startSimulation() {
  const bennu = window.__bennu;
  const dart  = window.__dart;
  const earth = window.__earth;
  if (!bennu || !dart || !earth) {
    showFatalError('Models not ready (Bennu/dart/Earth missing).');
    return;
  }

  dart.visible = true;

  // Read chosen menu option
  const opt = getSelectedOption();
  const days = parseFloat(document.getElementById('timeDays')?.value || '3650'); // days
  const deflectionKm = opt.delta_v_m_s * (days * 86400) / 1000.0; // km

  // Compute target (Bennu) world position
  const end = new THREE.Vector3();
  bennu.getWorldPosition(end);

  // Direction from Earth → Bennu
  const earthPos = new THREE.Vector3();
  earth.getWorldPosition(earthPos);
  const dirOut = end.clone().sub(earthPos).normalize();

  // Launch starts at Earth's center (or slightly inside), exits just beyond surface
  const earthR = earth.userData?.radius ?? 2.0;
  const LAUNCH_INSET = 0.0;       // 0 = exact center; set to >0 to start inside
  const EXIT_CLEAR   = 0.35;      // how far beyond the surface before switching to "approach"

  const launchStart = earthPos.clone().add(dirOut.clone().multiplyScalar(-LAUNCH_INSET));
  const exitPoint   = earthPos.clone().add(dirOut.clone().multiplyScalar(earthR + EXIT_CLEAR));

  // Put the dart at launchStart immediately
  dart.position.copy(launchStart);
  dart.lookAt(exitPoint);

  // Approach timing (for the segment exitPoint → Bennu)
  const distScene = exitPoint.distanceTo(end);
  // User-chosen velocity (km/s)
  const velKms = parseFloat(document.getElementById('velocity')?.value || '6.6');

  // Convert km/s → scene units per second
  // (divide by your scale factor for km → scene units)
  const velScene = velKms / SIM.UNIT_KM_PER_SCENE_UNIT;

  // Compute approach time
  const tApproach = Math.max(SIM.APPROACH_MIN_TIME ?? 0.35, distScene / Math.max(velScene, 1e-6));


  // Map deflection km → scene velocity during deflection phase
  const sceneDeflectPerSec = (deflectionKm / SIM.UNIT_KM_PER_SCENE_UNIT) / SIM.DEFLECTION_TIME;

  // Deflection direction: orthogonal to incoming
  const dirIn = end.clone().sub(exitPoint).normalize();
  const ortho = new THREE.Vector3(0, 1, 0).cross(dirIn).normalize();
  if (ortho.lengthSq() < 1e-6) ortho.set(1,0,0);
  const vDeflect = ortho.multiplyScalar(sceneDeflectPerSec);

  // Refresh the approach line (only from EXIT → BENNU)
  if (STATE.line) scene.remove(STATE.line);
  STATE.line = makeApproachLine(exitPoint, end);
  scene.add(STATE.line);

  // Lock button during sim
  if (btnStart) btnStart.disabled = true;

  // New first phase: LAUNCH (Earth core → just outside Earth)
  STATE.phase = 'launch';
  STATE.t0 = nowSec();
  STATE.launch = {
    start: launchStart,
    end: exitPoint,
    duration: 0.6   // seconds; tweak for how quickly it exits the Earth
  };

  // Queue the usual approach/deflect phases (will activate after launch)
  STATE.approach = { start: exitPoint, end, duration: tApproach };
  STATE.deflect  = { v: vDeflect, duration: SIM.DEFLECTION_TIME };

  STATE.contactDistance = estimateContactDistance(bennu, dart);

  // --- NEW: make the asteroid drift toward Earth until impact ---
  const earthPosForDrift = new THREE.Vector3();
  earth.getWorldPosition(earthPosForDrift);

  const bennuPosForDrift = new THREE.Vector3();
  bennu.getWorldPosition(bennuPosForDrift);

  // velocity direction: from Bennu toward Earth
  const inwardDir = earthPosForDrift.clone().sub(bennuPosForDrift).normalize();
  STATE.inward = {
    v: inwardDir.multiplyScalar(SIM.ASTEROID_INWARD_SPEED), // scene units/sec
    active: true
  };

  // VFX selection for impact
  STATE.vfxType = opt.vfx || 'small_impact_flash';
}


// === Helpers ===

// === Make an element draggable by a handle (fixed positioning) ===
// === Draggable (fixed) with correct cursor offset + clamping ===
function makeDraggable(el, handle, storageKey) {
  // If we previously saved a left/top, restore it; otherwise keep CSS right/top
  const saved = localStorage.getItem(storageKey);
  if (saved) {
    try {
      const p = JSON.parse(saved);
      if (typeof p.left === 'number' && typeof p.top === 'number') {
        el.style.left = p.left + 'px';
        el.style.top  = p.top  + 'px';
        el.style.right = 'auto';           // switch to left/top for dragging
      }
    } catch {}
  }

  let dragging = false;
  let offsetX = 0, offsetY = 0;

  const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

  const onDown = (e) => {
    if (e.target.closest('input,select,button,textarea')) return;
    dragging = true;
    el.classList.add('dragging');

    const rect = el.getBoundingClientRect();
    const clientX = (e.touches ? e.touches[0].clientX : e.clientX);
    const clientY = (e.touches ? e.touches[0].clientY : e.clientY);

    // cursor offset inside the element so it doesn't "jump"
    offsetX = clientX - rect.left;
    offsetY = clientY - rect.top;

    // switch from right-anchored CSS to left so movement is smooth
    el.style.left = rect.left + 'px';
    el.style.top  = rect.top  + 'px';
    el.style.right = 'auto';

    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('touchmove', onMove, { passive: false });
    window.addEventListener('touchend', onUp);
  };

  const onMove = (e) => {
    if (!dragging) return;
    if (e.cancelable) e.preventDefault();

    const clientX = (e.touches ? e.touches[0].clientX : e.clientX);
    const clientY = (e.touches ? e.touches[0].clientY : e.clientY);

    const rect = el.getBoundingClientRect();
    let left = clientX - offsetX;
    let top  = clientY - offsetY;

    left = clamp(left, 8, window.innerWidth  - rect.width  - 8);
    top  = clamp(top,  8, window.innerHeight - rect.height - 8);

    el.style.left = left + 'px';
    el.style.top  = top  + 'px';
  };

  const onUp = () => {
    if (!dragging) return;
    dragging = false;
    el.classList.remove('dragging');
    const rect = el.getBoundingClientRect();
    localStorage.setItem(storageKey, JSON.stringify({ left: rect.left, top: rect.top }));
    window.removeEventListener('pointermove', onMove);
    window.removeEventListener('pointerup', onUp);
    window.removeEventListener('touchmove', onMove);
    window.removeEventListener('touchend', onUp);
  };

  handle.addEventListener('pointerdown', onDown);
  handle.addEventListener('touchstart', onDown, { passive: true });
}

// === Make an element draggable by a handle (fixed positioning) =============

function renderOptions() {
  const sel = document.getElementById('strategy');
  if (!sel) return;
  sel.innerHTML = "";
  OPTIONS.forEach(opt => {
    const o = document.createElement('option');
    o.value = opt.id;
    o.textContent = opt.label;
    o.title = opt.tooltip || '';
    sel.appendChild(o);
  });
  sel.value = 'dart_nominal'; // default selection
  updateDetails();
}

function getSelectedOption() {
  const sel = document.getElementById('strategy');
  const id = sel?.value || 'baseline';
  return OPTIONS.find(o => o.id === id) || OPTIONS[0];
}

function updateDetails() {
  const el = document.getElementById('details');
  const t = parseFloat(document.getElementById('timeDays')?.value || '3650'); // days
  const opt = getSelectedOption();

  // compute deflection at chosen warning time
  const deflKm = opt.delta_v_m_s * (t * 86400) / 1000.0; // km
  const success = Math.round((opt.success_probability ?? 0) * 100);

  el.innerHTML =
    `<div><b>${opt.label}</b></div>
     <div>Δv ≈ ${opt.delta_v_m_s} m/s • Est. deflection: ~${deflKm.toFixed(0)} km @ ${t} days</div>
     <div>Estimated success: ${success}%</div>`;
}


function makeObjectDarkUnlit(root) {
  root.traverse(o => {
    if (!o.isMesh) return;

    const mats = Array.isArray(o.material) ? o.material : [o.material];
    for (let i = 0; i < mats.length; i++) {
      const m = mats[i];
      // If it’s PBR, kill environment + make very rough & non-metal.
      if (m && (m.isMeshStandardMaterial || m.isMeshPhysicalMaterial)) {
        m.envMap = null;
        if ('envMapIntensity' in m) m.envMapIntensity = 0;
        if ('metalness' in m) m.metalness = 0;
        if ('roughness' in m) m.roughness = 1;
        // Make base color very dark grey
        if ('color' in m) m.color.setRGB(0.05, 0.05, 0.05);
        // No self-emission
        if ('emissive' in m) m.emissive.setRGB(0, 0, 0);
        m.needsUpdate = true;
      } else {
        // If it’s an unlit/basic or unknown material, replace it with a dark PBR that ignores IBL
        const std = new THREE.MeshStandardMaterial({
          color: 0x0a0a0a,
          roughness: 1,
          metalness: 0
        });
        // Keep its color map if present
        if (m && m.map) {
          std.map = m.map;
          std.map.colorSpace = THREE.SRGBColorSpace;
        }
        mats[i] = std;
      }
    }
    // Reassign array if needed
    o.material = Array.isArray(o.material) ? mats : mats[0];
  });
}

function nowSec() { return performance.now() / 1000; }

function lerpVec3(out, a, b, k) {
  out.set(a.x + (b.x - a.x) * k, a.y + (b.y - a.y) * k, a.z + (b.z - a.z) * k);
  return out;
}

function makeApproachLine(start, end) {
  const geom = new THREE.BufferGeometry().setFromPoints([start.clone(), end.clone()]);
  // Bright cyan/teal pops against a dark, rocky asteroid
  const mat = new THREE.LineDashedMaterial({ color: 0x00ffd5, dashSize: 0.15, gapSize: 0.1 });
  const line = new THREE.Line(geom, mat);
  line.computeLineDistances();
  line.frustumCulled = false;
  return line;
}


// Estimate a reasonable contact distance using bounding spheres of two objects
function estimateContactDistance(a, b) {
  const sphereA = new THREE.Sphere();
  const sphereB = new THREE.Sphere();
  new THREE.Box3().setFromObject(a).getBoundingSphere(sphereA);
  new THREE.Box3().setFromObject(b).getBoundingSphere(sphereB);
  // Slightly under the sum to ensure we "hit" visually on contact
  return (sphereA.radius + sphereB.radius) * 0.98;
}


function spawnImpactFX(position) {
  const group = new THREE.Group();
  group.position.copy(position);

  // Put FX on dart layer so they render with the dart light if needed
  group.traverse(o => o.layers && o.layers.enable?.(LAYERS?.DART ?? 1));

  // --- A) Bright flash (longer) ---
  const flashGeo = new THREE.SphereGeometry(0.22, 28, 28);
  const flashMat = new THREE.MeshBasicMaterial({ color: 0xfff0c0, transparent: true, opacity: 1.0 });
  const flash = new THREE.Mesh(flashGeo, flashMat);
  group.add(flash);

  // --- B) Spark points (bigger, longer life) ---
  const count = SIM.PARTICLE_COUNT;
  const pGeom = new THREE.BufferGeometry();
  const positions = new Float32Array(count * 3);
  const velocities = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    const dir = new THREE.Vector3(Math.random()*2-1, Math.random()*2-1, Math.random()*2-1)
      .normalize()
      .multiplyScalar(1.0 + Math.random() * 2.0);
    positions.set([0,0,0], i*3);
    velocities.set([dir.x, dir.y, dir.z], i*3);
  }
  pGeom.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  pGeom.setAttribute('velocity', new THREE.BufferAttribute(velocities, 3));
  const pMat = new THREE.PointsMaterial({
    size: 0.20,              // ↑ clearly visible spark size
    transparent: true,
    opacity: 1.0,
    depthWrite: false
  });
  const points = new THREE.Points(pGeom, pMat);
  // render on dart layer
  points.layers.set?.(LAYERS?.DART ?? 1);
  group.add(points);

  // --- C) Chunky fragments (UNLIT so they’re always visible) ---
  const fragCount = SIM.FRAGMENT_COUNT;
  const baseGeo = new THREE.IcosahedronGeometry(1, 0);
  const fragMat = new THREE.MeshBasicMaterial({   // UNLIT: no lights needed
    color: 0xffa070,
    transparent: true,
    opacity: 1.0
  });
  const frags = new THREE.InstancedMesh(baseGeo, fragMat, fragCount);
  frags.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  frags.layers.set?.(LAYERS?.DART ?? 1);
  group.add(frags);

  // per-frag velocity + scale
  const fragVel = new Float32Array(fragCount * 3);
  const fragScale = new Float32Array(fragCount);
  const _m = new THREE.Matrix4();
  const _p = new THREE.Vector3();
  const _q = new THREE.Quaternion();
  const _s = new THREE.Vector3();

  for (let i = 0; i < fragCount; i++) {
    // a bit faster than points so chunks read clearly
    const dir = new THREE.Vector3(Math.random()*2-1, Math.random()*2-1, Math.random()*2-1)
      .normalize()
      .multiplyScalar(1.2 + Math.random() * 2.8);
    fragVel.set([dir.x, dir.y, dir.z], i*3);

    const s = THREE.MathUtils.lerp(SIM.FRAGMENT_SIZE_MIN, SIM.FRAGMENT_SIZE_MAX, Math.random());
    fragScale[i] = s;

    _p.set(0,0,0);
    _q.setFromEuler(new THREE.Euler(Math.random()*Math.PI, Math.random()*Math.PI, Math.random()*Math.PI));
    _s.set(s, s, s);
    _m.compose(_p, _q, _s);
    frags.setMatrixAt(i, _m);
  }
  frags.instanceMatrix.needsUpdate = true;

  group.userData = {
    flash, points, frags,
    fragVel, fragScale,
    birth: nowSec()
  };
  return group;
}
function updateImpactFX(group) {
  const { flash, points, frags, fragVel, birth } = group.userData;
  const age = nowSec() - birth;
  const dt = 0.016;

  // --- Flash over a longer time ---
  const fk = Math.min(age / SIM.IMPACT_FLASH_TIME, 1);
  flash.scale.setScalar(1 + fk * 12.0);
  flash.material.opacity = 1.0 * (1 - fk);

  // --- Points (longer lifetime) ---
  const life = SIM.PARTICLE_LIFETIME;
  const pk = Math.min(age / life, 1);
  points.material.opacity = 1.0 * (1 - pk);

  const pos = points.geometry.attributes.position.array;
  const vel = points.geometry.attributes.velocity.array;
  const drag = 0.985;
  for (let i = 0; i < vel.length; i += 3) {
    pos[i]   += vel[i]   * dt;
    pos[i+1] += vel[i+1] * dt;
    pos[i+2] += vel[i+2] * dt;
    vel[i]   *= drag;
    vel[i+1] *= drag;
    vel[i+2] *= drag;
  }
  points.geometry.attributes.position.needsUpdate = true;

  // --- Fragments (unlit; slowly drift + fade near the end) ---
  const _m = new THREE.Matrix4();
  const _p = new THREE.Vector3();
  const _q = new THREE.Quaternion();
  const _s = new THREE.Vector3();
  const fragDrag = 0.992;

  for (let i = 0; i < frags.count; i++) {
    frags.getMatrixAt(i, _m);
    _m.decompose(_p, _q, _s);

    const vx = fragVel[i*3+0];
    const vy = fragVel[i*3+1];
    const vz = fragVel[i*3+2];
    _p.x += vx * dt;
    _p.y += vy * dt;
    _p.z += vz * dt;

    fragVel[i*3+0] *= fragDrag;
    fragVel[i*3+1] *= fragDrag;
    fragVel[i*3+2] *= fragDrag;

    _m.compose(_p, _q, _s);
    frags.setMatrixAt(i, _m);
  }
  frags.instanceMatrix.needsUpdate = true;

  // Start fading fragments only near end of their life
  if (pk > 0.8) {
    frags.material.opacity = THREE.MathUtils.mapLinear(pk, 0.8, 1.0, 1.0, 0.0);
    frags.material.needsUpdate = true;
  }

  // Remove FX group once both flash and debris are done
  if (fk >= 1 && pk >= 1) {
    scene.remove(group);
  }
}



function setEnvIntensity(root, intensity) {
  root.traverse(o => {
    if (o.isMesh && o.material) {
      const mats = Array.isArray(o.material) ? o.material : [o.material];
      for (const m of mats) {
        if ('envMapIntensity' in m) m.envMapIntensity = intensity;
        m.needsUpdate = true;
      }
    }
  });
}

function enableShadows(root) {
  root.traverse(obj => {
    if (obj.isMesh) {
      obj.castShadow = true;
      obj.receiveShadow = false;
    }
  });
}

function centerAndScale(object3D, { targetSize = 2.0 } = {}) {
  const box = new THREE.Box3().setFromObject(object3D);
  const size = new THREE.Vector3();
  const center = new THREE.Vector3();
  box.getSize(size);
  box.getCenter(center);
  object3D.position.sub(center);
  const maxDim = Math.max(size.x, size.y, size.z);
  if (maxDim > 0) object3D.scale.setScalar(targetSize / maxDim);
}

// === Starfield generator ===
function addStarfield(count = 2000, radius = 1000) {
  const geom = new THREE.BufferGeometry();
  const positions = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    const r = radius * (0.8 + 0.2 * Math.random());
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    const x = r * Math.sin(phi) * Math.cos(theta);
    const y = r * Math.sin(phi) * Math.sin(theta);
    const z = r * Math.cos(phi);
    positions.set([x, y, z], i * 3);
  }
  geom.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  const mat = new THREE.PointsMaterial({ size: 1.2, sizeAttenuation: true });
  const stars = new THREE.Points(geom, mat);
  scene.add(stars);
}

// === Glow texture for Earth halo ===
function makeGlowTexture(size = 256) {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = size;
  const ctx = canvas.getContext('2d');
  const g = ctx.createRadialGradient(size/2, size/2, 0, size/2, size/2, size/2);
  g.addColorStop(0.0, 'rgba(135,170,255,0.75)');
  g.addColorStop(0.4, 'rgba(120,160,255,0.35)');
  g.addColorStop(1.0, 'rgba(120,160,255,0.0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

// === Earth creation (with IBL disabled) ===
async function addEarth(manager) {
  const textureLoader = new THREE.TextureLoader(manager);
  const earthRadius = 4.0;
  const earthDist   = 20.0;

  const tex = await textureLoader.loadAsync('https://threejs.org/examples/textures/land_ocean_ice_cloud_2048.jpg');
  tex.colorSpace = THREE.SRGBColorSpace;

  const earthMat = new THREE.MeshStandardMaterial({ map: tex, roughness: 1, metalness: 0 });
  const earthGeo = new THREE.SphereGeometry(earthRadius, 64, 64);
  const earth = new THREE.Mesh(earthGeo, earthMat);
  earth.position.set(-earthDist, 0, -earthDist * 0.3);
  earth.castShadow = false;
  earth.receiveShadow = false;

  // Earth on DEFAULT layer; no IBL
  earth.layers.set(LAYERS.DEFAULT);
  if ('envMapIntensity' in earth.material) earth.material.envMapIntensity = 0.0;

  scene.add(earth);

  scene.add(earth);
  window.__earth = earth;                 // ← add this
  earth.userData.radius = earthRadius;    // ← and this (we'll need its size)


  // Halo sprite (visual only)
  try {
    const glowTex = makeGlowTexture(256);
    const glowMat = new THREE.SpriteMaterial({ map: glowTex, transparent: true, depthWrite: false, opacity: 0.5 });
    const glow = new THREE.Sprite(glowMat);
    glow.scale.set(earthRadius * 4.0, earthRadius * 4.0, 1);
    glow.position.copy(earth.position);
    glow.layers.set(LAYERS.DEFAULT);
    scene.add(glow);
  } catch (e) {
    console.warn('Glow sprite generation failed; continuing without glow.', e);
  }
}

// === Boot: load everything ===
async function boot() {
  try {
    const manager = new THREE.LoadingManager();
    manager.onStart = () => setProgress(0);
    manager.onProgress = (url, loaded, total) => setProgress(Math.round((loaded / total) * 100));
    manager.onLoad = () => {
      setProgress(100);
      loadingEl?.classList.add('hidden');
      if (btnStart) btnStart.disabled = false;
    };

    // Earth
    await addEarth(manager);

    // Bennu
    let bennuScene = null;
    try {
      const bennuLoader = new GLTFLoader(manager);
      bennuLoader.setPath('/static/models/');
      const gltf = await bennuLoader.loadAsync('Asteroid_101955_Bennu.gltf'); // or .glb if that's your file
      bennuScene = gltf.scene;
      centerAndScale(bennuScene, { targetSize: 1.5 });
      bennuScene.position.set(0, 0, 0);
      enableShadows(bennuScene);
      scene.add(bennuScene);
      window.__bennu = bennuScene;

      // Bennu on DEFAULT layer; kill IBL influence
      bennuScene.traverse(o => {
        o.layers.enable(LAYERS.DEFAULT);
        o.layers.disable(LAYERS.DART);
      });
      setEnvIntensity(bennuScene, 0.0);
    } catch (e) {
      console.error('Bennu load error:', e);
      showFatalError('Failed to load Bennu. Check /static/models/Asteroid_101955_Bennu.(gltf|glb)');
    }

    scene.add(bennuScene);
    window.__bennu = bennuScene;

    // Keep Bennu on DEFAULT layer
    bennuScene.traverse(o => {
      o.layers.enable(LAYERS.DEFAULT);
      o.layers.disable(LAYERS.DART);
    });

    // 🔒 Force Bennu to stay dark (no IBL, no lights)
    makeObjectDarkUnlit(bennuScene);


    // Dart
    try {
      const dartLoader = new GLTFLoader(manager);
      dartLoader.setPath('/static/models/dart/');
      dartLoader.setResourcePath('/static/models/dart/');
      const gltf2 = await dartLoader.loadAsync('dart.gltf');
      const dart = gltf2.scene;
      centerAndScale(dart, { targetSize: 0.6 });

      // Dart ONLY on DART layer; enable IBL
      dart.traverse(o => {
        o.layers.enable(LAYERS.DART);
        o.layers.disable(LAYERS.DEFAULT);
        if (o.isMesh && o.material) {
          const mats = Array.isArray(o.material) ? o.material : [o.material];
          for (const m of mats) {
            if (m.map) m.map.colorSpace = THREE.SRGBColorSpace;
            if ('envMapIntensity' in m) m.envMapIntensity = 1.0;
            m.needsUpdate = true;
          }
        }
      });

      // Localized light that only affects the dart (layer 1)
      const dartLight = new THREE.PointLight(0xffffff, 2.5, 4.0, 2.0);
      dartLight.layers.set(LAYERS.DART);
      dartLight.position.set(0.0, 0.2, 0.3);
      dart.add(dartLight);

      dart.position.set(4.5, 1.0, 6.0);
      dart.lookAt(0, 0.5, 0);
      enableShadows(dart);
      scene.add(dart);
      window.__dart = dart;
      dart.visible = false; // ← hide dart at startup

    } catch (e) {
      console.error('Dart load error:', e);
      showFatalError('Failed to load dart model. Verify /static/models/dart/dart.gltf (+ bin/textures).');
    }

  } catch (err) {
    console.error(err);
    showFatalError(String(err));
  }
}

// Kick things off
boot();

// Hook Start button
if (btnStart) {
  btnStart.addEventListener('click', () => {
    if (STATE.phase !== 'idle') return;
    startSimulation();
  });
}

// Build the Mitigation options UI
// ---- Build the Mitigation options UI ----
renderOptions();
document.getElementById('strategy')?.addEventListener('change', updateDetails);
document.getElementById('timeDays')?.addEventListener('input', updateDetails);
document.getElementById('applyOption')?.addEventListener('click', updateDetails);
updateDetails();

// ---- FORCE INITIAL PANEL POSITIONS EACH REFRESH ----
// Always start the Mitigation menu at the same top-right position, and put the
// Kinetic Impactor panel directly below it. Then attach dragging.
(function initPanelPositionsAlways() {
  const MARGIN = 12;

  const menuEl = document.getElementById('menu');
  const kinEl  = document.getElementById('kineticMenu');

  // 1) Always clear any saved positions so we start from a known place
  try {
    localStorage.removeItem('mitigationMenuPos');
    localStorage.removeItem('kineticMenuPos');
  } catch {}

  // 2) Place mitigation menu at top-right (using left/top so dragging is smooth)
  requestAnimationFrame(() => {
    if (menuEl) {
      // Measure current width (fallback if zero on first frame)
      const rect = menuEl.getBoundingClientRect();
      const w = rect.width || 300;

      const left = Math.max(8, window.innerWidth - w - MARGIN);
      const top  = MARGIN;

      menuEl.style.left  = left + 'px';
      menuEl.style.top   = top  + 'px';
      menuEl.style.right = 'auto'; // we control via left/top for drag

      // 3) Place kinetic panel directly below mitigation
      if (kinEl) {
        const menuRect = menuEl.getBoundingClientRect();
        const kinRect  = kinEl.getBoundingClientRect();
        const kinLeft  = Math.max(8, Math.min(left, window.innerWidth - (kinRect.width || 300) - 8));
        const kinTop   = Math.max(8, Math.min(menuRect.bottom + MARGIN, window.innerHeight - (kinRect.height || 160) - 8));

        kinEl.style.left  = kinLeft + 'px';
        kinEl.style.top   = kinTop  + 'px';
        kinEl.style.right = 'auto';
      }
    }

    // (Re)attach draggable after setting initial positions
    const menuHandle = menuEl?.querySelector('.drag-handle');
    const kinHandle  = kinEl?.querySelector('.drag-handle');
    if (menuEl && menuHandle) makeDraggable(menuEl, menuHandle, 'mitigationMenuPos');
    if (kinEl && kinHandle)   makeDraggable(kinEl,  kinHandle,  'kineticMenuPos');
  });
})();



